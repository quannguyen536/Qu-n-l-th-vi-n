package controllers;

import errors.BusinessLogicException;
import interfaces.IController;
import models.Member;

import java.sql.SQLException;
import java.util.ArrayList;

public class memberController implements IController<Member> {
    private final ArrayList<Member> members;
    private memberService memberService;

    public memberController(memberService memberService) throws SQLException {
        this.memberService = memberService;
        members = memberService.findAll();
    }

    @Override
    public void display() {
        System.out.printf(Student.toStringHeader());
        for (Student student : this.members) {
            System.out.printf(student.toString());
        }
    }

    private Student findStudentById(long id) {
        Student student = null;
        for (int i = 0; i < this.members.size(); i++) {
            if (this.members.get(i).getId() == id) {
                student = this.members.get(i);
                break;
            }
        }
        return student;
    }

    private int findIndexByStudentId(long id) {
        int index = -1;
        for (int i = 0; i < this.members.size(); i++) {
            if (this.members.get(i).getId() == id) {
                index = i;
                break;
            }
        }
        return index;
    }

    @Override
    public void removeItem(long id) throws SQLException {
        Student student = this.findStudentById(id);
        if (student == null) {
            throw new BusinessLogicException(this.getClass(), "Không tìm thấy sinh viên với id đã cho");
        }
        this.members.remove(student);
        this.memberService.remove(id);
    }

    @Override
    public void update(Student student) throws SQLException {
        int index = this.findIndexByStudentId(student.getId());
        if (index == -1) {
            throw new BusinessLogicException(this.getClass(), "Không tìm thấy sinh viên với id đã cho");
        }
        this.members.set(index, student);
        this.memberService.update(student);
    }

    @Override
    public void insert(Student student) throws SQLException {
        this.members.add(student);
        this.memberService.save(student);
    }
}
