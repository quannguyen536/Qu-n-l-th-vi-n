package services;

import conf.Database;
import interfaces.IService;
import models.Book;
import models.Member;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

    public class StudentService implements IService<Member> {

        private Member member(ResultSet rs) throws SQLException {
            Member member = new Member(
                    rs.getLong("id"),
                    rs.getString("name"),
                    rs.getString("phone"),
                    rs.getString("address")
            );
            return member;
        }

        @Override
        public ArrayList<Member> findAll() throws SQLException {
            return null;
        }

        @Override
        public ArrayList<Book> findall() throws SQLException {
            return null;
        }

        @Override
        public boolean save(Member member) throws SQLException {
            return false;
        }

        @Override
        public boolean save(Student student) throws SQLException {
            PreparedStatement stmt = Database.getConnection().prepareStatement(
                    "INSERT INTO students(name, phone, address, age, gender, grade_id) VALUES (?, ?, ?, ?, ?, ?)");
            stmt.setString(1, student.getName());
            stmt.setString(2, student.getPhone());
            stmt.setString(3, student.getAddress());
            stmt.setInt(4, this.localDateTime.getYear() - student.getYearOfBirth());
            stmt.setInt(5, student.getGender().getValue()); // Assuming gender is stored as a string
            stmt.setLong(6, student.getGrade().getId());
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        }

        @Override
        public boolean remove(long id) throws SQLException {
            PreparedStatement stmt = Database.getConnection().prepareStatement("DELETE FROM students WHERE id = ?");
            stmt.setLong(1, id);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        }

        @Override
        public boolean update(Member member) throws SQLException {
            return false;
        }

        @Override
        public boolean update(Student student) throws SQLException {
            PreparedStatement stmt = Database.getConnection().prepareStatement(
                    "UPDATE students SET name = ?, address = ?, age = ?, gender = ?, grade_id = ? WHERE id = ?");
            stmt.setString(1, student.getName());
            stmt.setString(2, student.getAddress());
            stmt.setInt(3, this.localDateTime.getYear() - student.getYearOfBirth());
            stmt.setInt(4, student.getGender().getValue());
            stmt.setLong(5, student.getGrade().getId());
            stmt.setLong(6, student.getId());
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        }

        @Override
        public Student findById(long id) throws SQLException {
            Student student = null;
            PreparedStatement stmt = Database.getConnection().prepareStatement(
                    "SELECT s.id, s.name, s.phone, s.address, s.age, s.gender, g.id as grade_id, g.name as grade_name " +
                            "FROM students s JOIN grades g ON s.grade_id = g.id WHERE s.id = ?");
            stmt.setLong(1, id);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                student = studentMapper(rs);
            }
            return student;
        }
    }

}
